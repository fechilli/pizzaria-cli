const UsuariosServices = require('../services/UsuariosServices');

UsuariosServices.listar();