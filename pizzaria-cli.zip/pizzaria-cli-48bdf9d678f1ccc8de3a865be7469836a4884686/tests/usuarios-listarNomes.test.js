const UsuariosServices = require("../services/UsuariosServices");


UsuariosServices.listarNomes();