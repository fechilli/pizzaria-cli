const UsuariosServices = require('../services/UsuariosServices');

UsuariosServices.salvar([{nome:"Felipe", idade:51}, {nome:"Maria", idade:49}]);